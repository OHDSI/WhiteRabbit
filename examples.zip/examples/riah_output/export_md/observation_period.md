## Table name: observation_period

### Reading from patients

![](md_files/image1.png)

| Destination Field | Source field | Logic | Comment field |
| --- | --- | --- | --- |
| observation_period_id |  |  |  |
| person_id |  |  |  |
| observation_period_start_date |  |  |  |
| observation_period_end_date |  |  |  |
| period_type_concept_id |  |  |  |

