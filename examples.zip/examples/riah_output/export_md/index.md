# Source Data Mapping Approach to CDMV5.3.1

![](md_files/image3.png)

## Contents

[observation_period](observation_period.md)

[person](person.md)

[source_appendix](source_appendix.md)

