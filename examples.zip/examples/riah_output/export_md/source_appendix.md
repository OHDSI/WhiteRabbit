# Appendix: source tables

### Table: patients

| Field | Type | Most freq. value | Comment |
| --- | --- | --- | --- |
| id | character varying | 10ac74ae-b597-44d5-85ac-66278a2565a1 | Source field comment |
| birthdate | date | 1916-05-26 |  |
| deathdate | date |  |  |
| ssn | character varying | 999-50-5136 |  |
| drivers | character varying |  |  |
| passport | character varying |  |  |
| prefix | character varying | Mr. |  |
| first | character varying | Julio255 |  |
| last | character varying | Lemke654 |  |
| suffix | character varying |  |  |
| maiden | character varying |  |  |
| marital | character varying | M |  |
| race | character varying | white |  |
| ethnicity | character varying | irish |  |
| gender | character varying | F |  |
| birthplace | character varying | Boston  Massachusetts  US |  |
| address | character varying | 1084 Borer Vale Apt 20 |  |
| city | character varying | Boston |  |
| state | character varying | Massachusetts |  |
| county | character varying | Middlesex County |  |
| zip | character varying |  |  |
| lat | numeric | 42.5986737722432 |  |
| lon | numeric | -70.6042299777068 |  |
| healthcare_expenses | numeric | 193789.11 |  |
| healthcare_coverage | numeric | 0 |  |

### Table: organizations

| Field | Type | Most freq. value | Comment |
| --- | --- | --- | --- |
| id | character varying | db0acede-4abe-3c01-8d03-5c68a190d8c7 |  |
| name | character varying | STEWARD MEDICAL GROUP  INC |  |
| address | character varying | 100 HIGHLAND ST |  |
| city | character varying | CAMBRIDGE |  |
| state | character varying | MA |  |
| zip | character varying | 02186-3881 |  |
| lat | numeric | 42.376043 |  |
| lon | numeric | -71.11868 |  |
| phone | character varying |  |  |
| revenue | numeric | 0 |  |
| utilization | character varying | 29 |  |

### Table: conditions

| Field | Type | Most freq. value | Comment |
| --- | --- | --- | --- |
| start | date | 1956-06-01 |  |
| stop | date |  |  |
| patient | character varying | 10829a41-bb39-414b-ba10-c0eea7b133f3 |  |
| encounter | character varying | 4f5d7f00-e90f-48a2-b0d2-0fd8e6cecd1a |  |
| code | character varying | 444814009 |  |
| description | character varying | Viral sinusitis (disorder) |  |

